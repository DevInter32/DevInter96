a<template>
		<header>
         <router-link to="/" ><h1>Dev<b>Inter</b></h1></router-link>

         <input type='checkbox' id='menu-bar'>

         <label class='icon-menu' for='menu-bar'></label>

         <nav class='menu_dev'> 
             <router-link to="/blog" class='item medio'>Blog</router-link>
             <router-link to="/contacto" class='item medio' >Contacto</router-link>
          <div class="dropdown  ">
            <a class="dropdown-toggle dropbtn text-white  item medio "   id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{user_name}}</a>
                  <div class="dropdown-content btn bg-dark btn-block p-0">
                    <router-link to="/perfil"  class="btn bg-dark text-white btn-block btn_dropdown">Mi perfil</router-link>
                    <a @click="logout" class="btn bg-dark text-white btn-block btn_dropdown " >Cerrar sesion</a>
                  </div>
          </div>
             <!--<a @click="logout" class="item medio pointer" >Cerrar sesion</a>-->
         </nav>
    </header>
</template>

<script>
	export default{
        props:{
            user_name:String
        },
        methods: {
            logout() {
                document.getElementById('logout-form').submit();
            }
        }
    }
</script>

<style scoped>
	.pointer{
        cursor: pointer;

    }

.dropdown-toggle::after{
    margin-top: 10px;
}

    .dropbtn{
        cursor: pointer;
        height: auto;

    }
    
    .dropdown{
        display: inline-block;
    }



    .dropdown-content{
        display: none;
        /*position: absolute;
        width: 100%;
        min-width:160px;
        top: 30px;
        right: -20px;*/


        z-index: 1;
    }



    .dropdown:hover .dropdown-content{
        display: block;
    }

    .menu_dev a.btn_dropdown:hover{
        background-color:  #38c6d8!important;
    }

    @media (max-width: 699px){
        .dropdown{
            display: block;
            margin-right: 0px;
        }
    }
    @media(min-width: 700px){
        .dropdown{
            display: inline-block;
        }
    }
</style>