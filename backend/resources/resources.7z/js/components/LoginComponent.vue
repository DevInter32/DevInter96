<template>

<div class="container">
	<br>
	<br>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div v-if="hay_mensaje">
                <div class="row justify-content-center">
                    <div class="col-md-10">
                        <div :class="clase">
                            <h4 class="alert-heading">Mensaje Informativo</h4>
                            <p>{{texto_mensaje}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">

                <div class="card-header">Inicio de sesion</div>

                <div class="card-body">


                    <form method="POST" @submit.prevent="iniciar_sesion">
                        

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">Correo electronico</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" required autocomplete="email" autofocus v-model="correo">


                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right" >Contraseña</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control " name="password" v-model="clave" required autocomplete="current-password">

                            </div>
                        </div>

                        <!--<div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember">

                                    <label class="form-check-label" for="remember">
                                        Recuerdame
                                    </label>
                                </div>
                            </div>
                        </div>-->

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                   Iniciar Sesion
                                </button>

                                    <router-link to="/restaurar_clave" class="btn btn-link" >
                                        ¿Olvidaste tu contraseña ? Puedes recuperarla aqui
                                    </router-link>
                                
                                    <router-link to="/register" class="btn btn-link " >
                                        No tienes una cuenta? Puede registrarse aqui
                                    </router-link>
                                
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

</template>

<script>
	export default{
        props:{
        mensaje:String,
        tipo_mensaje:String
        },
        data(){
            return{
                correo:'',
                clave:'',
                hay_mensaje:false,
                clase:'',
                texto_mensaje:''
            }
        },
        methods:{
            iniciar_sesion(){
                const params={
                    //los coloco en ingles para usar el controlador del login que laravel trae por defecto
                    email:this.correo,
                    password:this.clave
                }
                
                /*axios.post('login',params)
                .then((response)=>{
                    console.log(response)
                    if(response.data.mensaje == "exito"){
                        this.$alertify.success('Login Completado');
                        document.location.href="http://127.0.0.1:8000" 
                    }else if(response.data.mensaje == "El correo no esta verificado"){
                        this.correo='';
                        this.clave='';
                        this.$alertify.message(response.data.mensaje);
                    }else if(response.data.mensaje == "el usuario no esta registrado o uno de los campos son iconrrectos"){
                        this.correo='';
                        this.clave='';
                        this.$alertify.error(response.data.mensaje);
                    }

                })
                .catch((error)=>{
                    console.log(error)
                })*/
                this.$http.post('login',params).
                    then(response=>{
                        if(response.data.mensaje == "exito"){
                            this.$alertify.success('Login Completado');
                            document.location.href="http://127.0.0.1:8000" 
                        }else if(response.data.mensaje == "El correo no esta verificado"){
                            this.correo='';
                            this.clave='';
                            this.$alertify.message(response.data.mensaje);
                        }else if(response.data.mensaje == "el usuario no esta registrado o uno de los campos son iconrrectos"){
                            this.correo='';
                            this.clave='';
                            this.$alertify.error(response.data.mensaje);
                        }
                    })
                    .catch(error=>{
                        console.log(error);
                    })
            }
        },mounted(){
            if(this.mensaje == "verificacion_correo"){
                this.hay_mensaje = true
                this.texto_mensaje="Verifique su correo para poder iniciar sesion"
                this.clase="alert alert-success";
            }else if(this.mensaje == "restauracion_clave"){
                this.hay_mensaje = true
                this.texto_mensaje="Su contraseña ha sido restablecida, inicie sesion con la nueva clave"
                this.clase="alert alert-success";
            }
        }
    }
</script>

<style>
	.card{
		width: 100%!important;
	}
    .text-black{
        color: black;
    }
</style>