<template>
<div>
		
	
	<div class="mi_fondo">
		<div class="imagen_fondo" :style="imagen">
          <div class="contenido-centro d-flex justify-content-center align-items-center">
            <div>
            	<h1 class="text-white">{{entrada.titulo}}</h1>
            	<div class="d-flex justify-content-center">



					<div class="d-flex mt-1 text-center mx-auto">
		                <li class="text-white autor"><i class="icon ml-0 icon-calendar pr-2"></i><span class="text-white">{{entrada.dia}} {{entrada.mes}}, {{entrada.year}}</span>	|	</li>
		                <li class="text-white autor pr-2 pl-1 pading-top"><span class="text-white">       tiempo de lectura: {{entrada.tiempo_lectura}}  </span></li>

		            </div>	
            	</div>

					<div class="mx-auto mt-2">
						<div class="d-flex justify-content-center">
							<img :src="imagen_autor" alt="" class="img_autor rounded-circle">
						</div>
						<div class="d-flex justify-content-center">
		                <p class="text-white autor"><i class="icon ml-0 icon-user pr-2"></i><span class="text-white">{{entrada.autor}} </span>		</p>
						</div>
					</div>

            </div>

          </div>
		</div>
	</div>

	<div class="container">

		<div class="row d-flex justify-content-center mt-5 pt-3" v-if="cargando" >
			
				<div class="sk-chase">
				  <div class="sk-chase-dot"></div>
				  <div class="sk-chase-dot"></div>
				  <div class="sk-chase-dot"></div>
				  <div class="sk-chase-dot"></div>
				  <div class="sk-chase-dot"></div>
				  <div class="sk-chase-dot"></div>
				</div>
		
		</div>

		<div>
			<div class="row" >
				
			
				<div class="card col-md-10 mx-auto px-0 col-12">
					
					    <div class="card-body ">
					     
			
						<br>
					    <div class="contenido_entrada text-justify" id="descripcion"></div >



					    
					    <br>
				    </div>
				<comentario-component :user_id="user_id" :id_entrada="entrada_id"></comentario-component>
				</div>
				
			</div>
		<!--seccion de comentarios-->
			
			

		</div>

	</div>
</div>
</template>



<script>
	export default{
		props:{
			user_id:String
		},
		data(){
			return{
				imagen:'',
				entrada:Object,
				comentario:'',
				entrada_id:'',
				cargando:false,
				imagen_autor:''

			}
		},
		methods:{
			obtenerEntrada(){
				
				const id = this.$route.params.id;
				this.entrada_id = id;
				this.cargando=true;
				axios.get('../api/entradas/'+id).
				then((response)=>{
					this.cargando=false;
					this.entrada = response.data;
					
					this.entrada_id = this.entrada.id
					this.imagen="background-image: url(../storage/img/entradas/"+this.entrada.img_vista_completa+");";
					var descripcion=	$("#descripcion");
					 
					 var p = document.createElement("p");
					 p.innerHTML = this.entrada.descripcion;
					 descripcion.append(p);
		            this.entrada.created_at = this.entrada.created_at.replace('-',' ');
		            this.entrada.created_at = this.entrada.created_at.replace('-',' ');
		            var dia = this.entrada.created_at.split(' ')[0];
		            var mes= this.entrada.created_at.split(' ')[1];
		            var year= this.entrada.created_at.split(' ')[2];

		            if(mes == 'Dec'){
		              mes = "Dic";
		            }else if(mes == 'Nov'){
		            	mes = "Nov"
		            }else if(mes == 'Aug'){
		            	mes = 'Ago'
		            }else if(mes == 'Apr'){
		            	mes = 'Abr'
		            }
		            this.imagen_autor="../storage/img/usuarios/"+this.entrada.imagen_autor;

		            this.entrada.dia = dia;
		            this.entrada.mes = mes;
		            this.entrada.year = year









		            console.log(this.imagen);

				})
				.catch((error)=>{
					console.log(error);
				})


			},

		},
		created(){

				var offSet = 70;
				var obj = $("#contenido");
				if(obj.length){
					var offs = obj.offset();
					var targetOffset = offs.top - offSet;
					$('html,body').animate({scrollTop:targetOffset},1000);
				}else{
					
				}

			this.obtenerEntrada();


		},




	}
</script>

<style >

.pading-top{
	padding-top:3px;
}

.imagen_fondo{
  background-size: cover;

background-repeat: no-repeat;

margin-bottom: 30px;

background-position: center;

overflow: hidden;
height: 100%;
width: 100%;
}


.mi_fondo{
	height: 500px;
	position: static;
	width: 100%;
	top: 2em;
}

.contenido-centro{
  text-align: center;


height: 100%;

background:
rgba(0, 0, 0, 0.6);

-webkit-transition: 0.5s;

-moz-transition: 0.5s;

-o-transition: 0.5s;

transition: 0.5s;

position: relative;
}


.contenido_entrada img{
	width: 80%!important;
	height: 300px!important;
}

.img_autor{
	height: 100px;
	width: 100px;
}

.ocultar{
  opacity: 0;
}

.desaparecer{
  height: 0px!important;

}
.contenido_entrada{
	font-size: 16px;
}


.icon{
	font-size: 20px;
	color: #gray;
}


/*CODIGO PARA EL SPINNER */

.sk-chase {
  width: 40px;
  height: 40px;
  position: relative;
  animation: sk-chase 2.5s infinite linear both;
}

.sk-chase-dot {
  width: 100%;
  height: 100%;
  position: absolute;
  left: 0;
  top: 0; 
  animation: sk-chase-dot 2.0s infinite ease-in-out both; 
}

.sk-chase-dot:before {
  content: '';
  display: block;
  width: 25%;
  height: 25%;
  background-color: #000;
  border-radius: 100%;
  animation: sk-chase-dot-before 2.0s infinite ease-in-out both; 
}

.sk-chase-dot:nth-child(1) { animation-delay: -1.1s; }
.sk-chase-dot:nth-child(2) { animation-delay: -1.0s; }
.sk-chase-dot:nth-child(3) { animation-delay: -0.9s; }
.sk-chase-dot:nth-child(4) { animation-delay: -0.8s; }
.sk-chase-dot:nth-child(5) { animation-delay: -0.7s; }
.sk-chase-dot:nth-child(6) { animation-delay: -0.6s; }
.sk-chase-dot:nth-child(1):before { animation-delay: -1.1s; }
.sk-chase-dot:nth-child(2):before { animation-delay: -1.0s; }
.sk-chase-dot:nth-child(3):before { animation-delay: -0.9s; }
.sk-chase-dot:nth-child(4):before { animation-delay: -0.8s; }
.sk-chase-dot:nth-child(5):before { animation-delay: -0.7s; }
.sk-chase-dot:nth-child(6):before { animation-delay: -0.6s; }

@keyframes sk-chase {
  100% { transform: rotate(360deg); } 
}

@keyframes sk-chase-dot {
  80%, 100% { transform: rotate(360deg); } 
}

@keyframes sk-chase-dot-before {
  50% {
    transform: scale(0.4); 
  } 100%, 0% {
    transform: scale(1.0); 
  } 
}



/* FIN DE CODIGO PARA EL SPINNER */



.blog-info-link li {
    font-size: 14px;
     list-style: none;
     float: left;

}

.text-black{
	color: black;
}

.autor{
	opacity: .7;
}

pre.ql-syntax{
	border-radius: 5px 5px;
	background:#272822;
	color: white;
	padding: 10px;
	height: 300px;
}

.ql-align-center {
    text-align: center;
}

.ql-align-right {
    text-align: right;
}


</style>