<template>


    <div >
        <br>

        <div class="row col-6 mb-3">
            

            <div class="card ">

                <div class="card-body row">
                    <div class="col-8">
                        <h3>Nueva Entrada</h3>
                    </div>

                </div>


            </div>
        </div>
        
            <div class="card pb-4">
            
                <form id="entrada_form" @submit.prevent="publicar_entrada" enctype="multipart/form-data">
                

                    
               
                    <h4 class="text-center"><strong>Titulo de la entrada</strong></h4>
                    <div class="col-8 mx-auto">
                        <input type="text" class="form-control" v-model="titulo">
                    </div>


                
                    <h5 class="text-center mt-4">Descripcion de la entrada</h5>
                <div class="row">
                    <div class="col-10 mx-auto">
                        <vue-editor id="editor" useCustomImageHandler @image-added="handleImageAdded" v-model="htmlForEditor"> </vue-editor>
                    </div>

                 </div>

                 <div class="row mt-4">
                     <div class="col-3 text-center">Subir Imagen previa</div>

                     <div class="col-6">
                         <input type="file" class="form-control" id="file_img_previa">
                     </div>
                 </div>

                 <div class="row">
                     <div class="col-3 text-center">Subir Imagen Completa</div>

                     <div class="col-6">
                         <input type="file" class="form-control" id="file_img_completa">
                     </div> 
                 </div>

                 <div class="row mt-4">
                     <div class="col-3 text-center">Duracion de la lectura</div>

                     <div class="col-6">
                         <input type="text" class="form-control" v-model="tiempo_lectura">
                     </div> 
                 </div>


                <div class="p-5">
                <validation-errors :errors="validationErrors" v-if="validationErrors"></validation-errors>        
                </div>


                 <div class="row mt-3">
                     <div class="col-6 mx-auto">
                         <button class="btn btn-success btn-block">Publicar entrada</button>
                     </div>
                 </div>
            
             </form>


            </div>



            



    </div>
</template>

<script>
import { VueEditor } from "vue2-editor";





    export default {
          components: {
            VueEditor
          },
        name: 'app',
        data() {
            return {
                titulo:'',
                htmlForEditor: "",
                tiempo_lectura:"",
                validationErrors:'',
            };
        },
        methods:{
            publicar_entrada(){
            	this.$alertify.success('Procesando Peticion... ');
                var formData = new FormData();
                var img_previa = document.querySelector("#file_img_previa");
                formData.append("file",img_previa.files[0]);

                var img_completa = document.querySelector("#file_img_completa");

                formData.append("file_completa",img_previa.files[0]);

                formData.append("titulo",this.titulo);

                formData.append("descripcion",this.htmlForEditor);


                formData.append("tiempo_lectura",this.tiempo_lectura);

                axios.post("../api/entradas",formData)
                .then((response)=>{
                    this.$alertify.success('Se ha publicado su entrada');
                    this.resetForm();
                })
                .catch((error)=>{
                    this.validationErrors = error.response.data.errors;
                    console.log(error)
                })




            },
            handleImageAdded: function(file, Editor, cursorLocation, resetUploader) {
                  // An example of using FormData
                  // NOTE: Your key could be different such as:
                  // formData.append('file', file)

                  var formData = new FormData();
                  formData.append("image", file);

                  axios({
                    url: "../api/test",
                    method: "POST",
                    data: formData
                  })
                    .then(result => {
                      let url = "../storage/img/imagenes_articulos/" + result.data.url; // Get url from response
                      console.log(result);
                      Editor.insertEmbed(cursorLocation, "image", url);
                      resetUploader();
                    })
                    .catch(err => {
                      console.log(err);
                    });
            },
            resetForm(){
            	this.titulo='';
            	this.htmlForEditor='';
            	this.tiempo_lectura='';
            	$("#entrada_form").reset();
            }
   
        },
        /*created(){
            this.editor
                .create( document.querySelector( '#editor' ), {
                    plugins: [ this.upload],
                    simpleUpload: {
                        // Feature configuration.
                    }
                } )
                .then((response)=>{
                    console.log(response)
                })
                .catch((error)=>{
                    console.log(error)
                })
                }*/
    }
</script>

<style >
.ql-editor pre.ql-syntax{
    height: auto!important;
}
</style>