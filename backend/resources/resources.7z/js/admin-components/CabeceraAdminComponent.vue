<template>
	<nav class="navbar navbar-expand-lg navbar-light bg-primary">
		<a href="#" class="navbar-brand text-white">DevInter-Admin</a>

		<ul class="navbar-nav ml-auto ">

		  <div class="dropdown mr-3">
		    <a class="dropdown-toggle dropbtn text-white py-3"   id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">{{usuario}}</a>
		          <div class="dropdown-content">
		            <router-link to="/admin/cambiar_credenciales"  class="btn bg-light text-black btn-block">Cambiar credenciales</router-link>
		            <router-link to="/admin/usuarios"  class="btn bg-light text-black btn-block">Usuarios</router-link>
	            	<router-link to="/admin/entradas"  class="btn bg-light text-black btn-block">Ver Entradas</router-link>
	            	<router-link to="/admin/comentarios"  class="btn bg-light text-black btn-block">Ver Comentarios</router-link>
	            	<a @click="logout" class="btn bg-light text-black btn-block" >Cerrar sesion</a>
		          </div>
		  </div>

		</ul>
	</nav>

</template>

<script>
	export default{
		props:{
			usuario:''
		},
        methods: {
            logout() {
                document.getElementById('logout-form').submit();
            }
        }
	}
</script>

<style scoped>

	.dropbtn{
		cursor: pointer;
	}
	
	.dropdown{
		display: inline-block;
	}

	.dropdown-content{
		display: none;
		position: absolute;
		width: 100%;
		min-width:160px;
		top: 30px;
		right: -20px;


		z-index: 1;
	}

	.dropdown:hover .dropdown-content{
		display: block;
	}

	/*li{
		display: block;
		transition-duration: 0.5s;
	}
	li:hover{
		cursor: pointer;
	}
	ul li ul{
		visibility: hidden;
		opacity: 0;
		position: absolute;
		transition:all 0.5s ease;
		margin-top: 1rem;
		left: 0;
		display: none;
	}
	ul li:hover ul, ul li ul:hover{
		visibility: visible;
		opacity: 1;
		display: block;
	}
	ul li ul li{
		clear: both;
		width: 100%;
	}

	.dropdown-li{
		position: relative;
	}*/



</style>