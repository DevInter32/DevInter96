<template>
	<div>
		<br>

        <div class="row col-md-8 col-lg-6 col-12">


            <div class="card ">

                <div class="card-body row">
                    <div class="col-md-4 col-12">
                        <h3 class="text-center">Usuarios</h3>
                    </div>
                    <div class="col-md-8 col-8 mx-auto">
                        <router-link to="/admin/agregar_usuario" class="btn btn-primary btn-block">Agregar Usuario</router-link>
                    </div>
                </div>


            </div>
        </div>


		<br><br>

        <v-server-table ref="table" :columns="columns" :url="url" :options="options">
            <div slot="role_id" slot-scope="props">
                {{mostrar_rol(props.row.role_id)}}
            </div>

            <div slot="acciones" slot-scope="props">
                <button class="btn btn-warning" data-toggle="modal" data-target="#abrirmodal" @click="pasar_valores(props.row.id,props.row.name,props.row.role_id)">Cambiar Estado</button>
            </div>
        </v-server-table>




            <!--Inicio del modal agregar-->
            <div class="modal fade" id="abrirmodal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
                <div class="modal-dialog modal-primary modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Cambiar Estado</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">×</span>
                            </button>
                        </div>

                        <div class="modal-body">


                            <form  method="POST" class="form-horizontal" @submit.prevent="cambiar_rol_usuario" >

                                <input type="hidden" id="id_usuario" name="id_usuario" v-model="id_usuario">
                               <div class="row">


                                    <label for="" class="col-md-3">Usuario:</label>

                                    <span class="col-md-9 text-center" id="usuario" name="usuario">Nombre del usuario</span>

                                </div>
                            <div class="row">


                                <label for="" class="col-md-3">Estado</label>

                                <div class="col-md-9">
                                    <select name="" id="" class="form-control" v-model="rol_usuario">
                                        <option value="0" disbaled>Seleccione</option>

                                        <option v-for="(rol) in roles" :value="rol.id" :key="rol.id">{{rol.name}}</option>

                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-8-offset-2 mx-auto text-center">
                                    <button class="btn-success" type="submit">Cambiar Estado</button>
                                </div>
                            </div>



                            </form>
                        </div>

                    </div>
                    <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
            </div>
            <!--Fin del modal-->












	</div>
</template>

<script>
	export default{
        data () {
        	const labels={
        		nombre:"Nombre de usuario",
        		rol:"Rol del usuario",
        		fecha:"Fecha de ingreso",
        		accion:"Acciones"
        	}

            return {
                roles:[],
                id_usuario:'',
                rol_usuario:'',
                url: '../api/usuarios',
                columns: ['id','name', 'role_id', 'created_at', 'acciones'],
                options: {
                    filterByColumn: true,
                    perPage: 10,
                    perPageValues: [10, 25, 50, 100, 500],
                    headings: {
                        name: labels.nombre,
                        role_id:labels.rol,
                        created_at:labels.fecha,
                        accion:labels.accion


                    },
                    customFilters: ['name'],
                    sortable: ['name'],
                    filterable: ['name'],
                    requestFunction: function (data) {
                        return window.axios.get(this.url, {
                            params: data
                        })
                        .catch(function (e) {
                            this.dispatch('error', e);
                        }.bind(this));
                    }
                }
            }
        },
        methods:{
            mostrar_rol(rol){
                if(rol == '1'){
                    return "Administrador"
                }else{
                    return "Usuario"
                }
            },
            cargar_roles(){
                axios.get('../api/roles')
                .then((response)=>{
                    this.roles = response.data
                })
            },
            pasar_valores(id,name,role_id){


                //console.log('modal abierto');
                // modal.find('.modal-title').text('New message to ' + recipient)

                var modal = $(".modal");
                modal.find('.modal-body #id_usuario').val(id);
                modal.find('.modal-body #usuario')[0].innerHTML=name;
                console.log(role_id);
                this.id_usuario = id;
                this.rol_usuario = role_id;


            },
            cambiar_rol_usuario(){
                const params = {
                    id_usuario:this.id_usuario,
                    rol:this.rol_usuario
                }
                axios.put('../api/rol/'+this.id_usuario,params)
                .then((response)=>{
                    this.$refs.table.refresh();
                    console.log(response)
                })
                .catch((error)=>{
                    console.log(error)
                })

            }
        },
        created(){
            this.cargar_roles();
        }

	}
</script>

<style>

</style>
