<template>
	<div>
		<br>

		<div class="row col-md-8 col-lg-6 col-12">
			

			<div class="card ">

				<div class="card-body row">
					<div class="col-md-4 col-12">
						<h3 class="text-center">Entradas</h3>
					</div>
					<div class="col-md-8 col-8 mx-auto">
						<router-link to="nueva_entrada" class="btn btn-primary btn-block">Añadir Entrada</router-link>
					</div>
				</div>


			</div>
		</div>


		<br><br>

        <v-server-table ref="table" :columns="columns" :url="url" :options="options">


            <div slot="acciones" slot-scope="props">
                <router-link :to="get_ruta(props.row)" class="btn btn-warning">Editar Publicacion</router-link>
                <button class="btn btn-danger" @click="eliminar_entrada(props.row.id)">Eliminar Publicacion</button>
            </div>
        </v-server-table>



	</div>
</template>

<script>
	export default{
		data () {
        	const labels={
                id:"id",
        		titulo:"Titulo de la entrada",

        		fecha:"Fecha de publicacion",
        		accion:"Acciones"
        	}

            return {

                url: '../api/entradas_table',
                columns: ['id','titulo', 'created_at', 'acciones'],
                options: {
                    filterByColumn: true,
                    perPage: 10,
                    perPageValues: [10, 25, 50, 100, 500],
                    headings: {
                        id:labels.id,
                        titulo: labels.titulo,
                        created_at:labels.fecha,
                        accion:labels.accion


                    },
                    customFilters: ['titulo'],
                    sortable: ['titulo'],
                    filterable: ['titulo'],
                    requestFunction: function (data) {
                        return window.axios.get(this.url, {
                            params: data
                        })
                        .catch(function (e) {
                            this.dispatch('error', e);
                        }.bind(this));

                    }
                }
            }
        },
        methods:{
            mostrar_rol(rol){
                if(rol == '1'){
                    return "Administrador"
                }
            },
            get_ruta(fila){
                return "../admin/editar_entrada/"+fila.id;
            },
            eliminar_entrada(id){
                axios.delete('../api/entrada/'+id)
                .then((response)=>{
                    console.log(response)
                    this.$alertify.success('Se ha eliminado la entrada');
                    this.$refs.table.refresh();
                })
                .catch((error)=>{
                    console.log(error)
                })
            }
        }
	}
</script>

<style>
    
</style>