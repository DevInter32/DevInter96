import VueRouter from 'vue-router'
import VueAlertify from 'vue-alertify'

import HomeComponent from './components/HomeComponent.vue'
import BlogComponent from './components/BlogComponent.vue'
import ContactoComponent from './components/ContactoComponent.vue'
import LoginComponent from './components/LoginComponent.vue'
import RegisterComponent from './components/RegistrarseComponent.vue'
import SingleEntradaComponent from './components/SingleEntradaComponent.vue'
import PerfilComponent from './components/PerfilComponent.vue'

import HomeAdminComponent from './admin-components/HomeAdminComponent.vue'
import CredencialesAdminComponent from './admin-components/CredencialesAdminComponent.vue'
//import CabeceraAdminComponent from './admin-components/CabeceraAdminComponent.vue'
import UsuariosAdminComponent from './admin-components/UsuariosAdminComponent.vue'
import EntradasAdminComponent from './admin-components/EntradasAdminComponent.vue'
import NuevaEntradaAdminComponent from './admin-components/NuevaEntradaAdminComponent.vue'
import ComentariosAdminComponent from './admin-components/ComentariosAdminComponent.vue'
import EditarEntradaAdminComponent from './admin-components/EditarEntradaAdminComponent.vue'
import RecuperarCuentaComponent from './components/RecuperarCuentaComponent.vue'
import RestaurarClaveComponent from './components/RestaurarClaveComponent.vue'
import AgregarUsuarioComponent from './admin-components/AgregarUsuarioComponent.vue'
require('./bootstrap');

window.Vue = require('vue');

import VueResource from 'vue-resource';
Vue.use(VueResource);

//necesario para http post, put, delete channel routes
Vue.http.interceptors.push((request, next) => {
    const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
    request.headers.set('X-CSRF-TOKEN', csrfToken);
    next();
});



import {ServerTable} from 'vue-tables-2';
Vue.use(ServerTable, {}, false, 'bootstrap4', 'default');





import CKEditor from '@ckeditor/ckeditor5-vue';

Vue.use( CKEditor );

/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i);
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default));

Vue.component('validation-errors',require('./components/ValidationErrors.vue').default);
Vue.component('example-component', require('./components/ExampleComponent.vue').default);
Vue.component('entrada-component',require('./components/EntradaComponent.vue').default);
Vue.component('cabecera-component',require('./components/CabeceraComponent.vue').default);
Vue.component('cabecera-auth-component',require('./components/CabeceraAuthComponent.vue').default);
Vue.component('cabecera-admin-component',require('./admin-components/CabeceraAdminComponent').default);
Vue.component('comentario-component',require('./components/ComentarioComponent.vue').default);
Vue.component('entrada-destacada-component',require('./components/EntradaDestacadaComponent.vue').default);
Vue.use(VueRouter);
Vue.use(VueAlertify);


const rutas = [
	{path:'/',component:HomeComponent},
	{path:'/blog',component:BlogComponent},
	{path:'/contacto',component:ContactoComponent},
	{path:'/login',component:LoginComponent},
	{path:'/register',component:RegisterComponent},
	{path:'/entradas/:id',component:SingleEntradaComponent},
	{path:'/perfil',component:PerfilComponent},
	{path:'/restaurar_clave',component:RecuperarCuentaComponent},
	{path:'/restaurar_clave/:token',component:RestaurarClaveComponent},
	{path:'/admin',component:HomeAdminComponent},
	{path:'/admin/cambiar_credenciales',component:CredencialesAdminComponent},
	{path:'/admin/usuarios',component:UsuariosAdminComponent},
	{path:'/admin/entradas',component:EntradasAdminComponent},
	{path:'/admin/nueva_entrada',component:NuevaEntradaAdminComponent},
	{path:'/admin/comentarios',component:ComentariosAdminComponent},
	{path:'/admin/editar_entrada/:id',component:EditarEntradaAdminComponent},
	{path:'/admin/agregar_usuario',component:AgregarUsuarioComponent}

]

const router= new VueRouter({
	mode:'history',
	routes:rutas
})


/**
 * Next, we will create a fresh Vue application instance and attach it to
 * the page. Then, you may begin adding components to this application
 * or customize the JavaScript scaffolding to fit your unique needs.
 */

const app = new Vue({
    el: '#app',
    router:router,


});
