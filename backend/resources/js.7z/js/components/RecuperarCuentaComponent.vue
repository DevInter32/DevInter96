<template>
    <div class="container">
        <div class="row justify-content-center mt-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Recuperar contraseña</div>

                    <div class="card-body">
                        <form method="POST" @submit.prevent="requestResetPassword">
                        <validation-errors :errors="validationErrors" v-if="validationErrors"></validation-errors>


                            <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right">Direccion de correo</label>

                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control " name="email" v-model="email" required autocomplete="email">


                                </div>
                            </div>

  



                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Recuperar Contraseña 
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>



        <div class="mt-2 pt-3 " v-if="cargando"> 
            <h3 class="text-center">Enviando correo para la restauracion de la cuenta</h3>

            <div class="row d-flex justify-content-center pt-3  pb-5"  >
                    
                    

                    <div class="sk-chase">
                      <div class="sk-chase-dot"></div>
                      <div class="sk-chase-dot"></div>
                      <div class="sk-chase-dot"></div>
                      <div class="sk-chase-dot"></div>
                      <div class="sk-chase-dot"></div>
                      <div class="sk-chase-dot"></div>
                    </div>
            
            </div>
        </div>



                </div>
            </div>
        </div>
    </div>
</template>

<script>

    export default{
        data(){
            return{
                email:'',
                validationErrors:'',
                cargando:false
            }
        },
        methods:{
        requestResetPassword() {
            this.cargando=true;
            this.$http.post("./reset-password", {email: this.email}).then(result => {
                this.cargando=false;
                this.response = result.data;
                console.log(result.data);
                this.$alertify.success('Se ha enviado el correo');
                document.location.href="http://127.0.0.1:8000/login";
                
            }, error => {
                this.cargando=false;
                this.$alertify.success('No se pudo enviar el correo');            
            });
        }
        }
    }
    
</script>
