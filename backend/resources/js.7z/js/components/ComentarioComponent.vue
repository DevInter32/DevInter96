<template>
  <div class="w-100">
    <div class="card-comments mb-3 text-justify">
      <div class="card-header font-weight-bold">Comentarios</div>
      <div class="card-body">
        <!--Este es el codigo que necesito-->

        <!-- comentario unitario-->
        <div class="media d-block d-md-flex mt-3">
          <div v-if="hay_comentarios">
            <div v-for="comentario in comentarios" :key="comentario.id"></div>
          </div>

          <img
            class="d-flex mb-3 mx-auto img-fluid rounded-circle img-avatar-comment"
            :src="comentario.user.imagen_perfil"
            alt="Generic placeholder image"
          />
          <div class="media-body text-center text-md-left ml-md-3 ml-0">
            <h5 class="mt-0 font-weight-bold">{{comentario.user.name}}</h5>
            <p class="comment-date">{{comentario.created_at}}</p>
            <a href class="pull-right">
              <i class="fas fa-reply"></i>
            </a>
            <!--Contenido del comentario-->
            {{comentario.comentario}}
            <!--<div class="reply block d-flex justify-content-end">
                                    <button type="button" class="btn btn-success waves-effect button-reply" id="button-reply-1" @click="mostrar_formulario_respuesta" >Responder</button>
                        </div>
                        <div class="col-xs-10 modal-reply desaparecer ocultar" id="modal-reply-1" role="dialog">
                                     <form method="POST">
                                        <input type="hidden" name="profile" id="id_profile" value="">
                                        <input type="hidden" name="comment" id="id_comment" value="">

                                        <input type="hidden" name="post" id="id_post" value="">

                                         <textarea name="" id="" cols="3" class="form-control"></textarea>
                                        <div class="text-center">
                                          <button class="btn btn-info btn-sm" type="submit">Publicar Respuesta</button>
                                        </div>
                                      </form>

            </div>-->
          </div>
        </div>
        <!--.media block-->

        <div
          v-if="!hay_comentarios"
          class="d-flex justify-content-center align-items-center align-content-center"
          style="height:60px"
        >
          <h5 class="align-self-center text-center">No hay comentarios disponibles</h5>
        </div>

        <!-- PARA cuando el comentario tenga respuesta -->
        <!-- y SEA igual al id del comentario -->

        <!--<div class="media d-block d-md-flex mt-3 offset-md-1 offset-3 mb-3" >
                                    <img class="d-flex mb-3 img-fluid rounded-circle img-avatar" src="img/avatar_response.jpg"
                                      alt="Generic placeholder image">
                                    <div class="media-body  text-left ml-md-3 ml-0">

                                      <h5 class="mt-0 font-weight-bold">Usuario 2
                                      </h5>
                                        <p class="comment-date">en respuesta a Administrador</p>
                                        <p class="comment-date">15 Jan</p>

                                        <a href="" class="pull-right">
                                          <i class="fas fa-reply"></i>
                                        </a>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Recusandae ullam quisquam aspernatur facilis dolor debitis, aperiam saepe distinctio sed eligendi delectus quidem amet reprehenderit expedita quae, sint, eum perspiciatis sapiente!
                                      </div>
        </div>-->

        <!-- fin de comentario unitario-->

        <!-- Formulario para publicar comentario-->

        <div class="form-group mt-4" v-if="user_id">
          <label for="quickReplyFormComment">Tu comentario</label>
          <form method="POST" @submit.prevent="enviar_comentario">
            <textarea name id cols="3" class="form-control" v-model="comentario"></textarea>

            <div class="text-center mt-3 col-6 mx-auto">
              <button class="btn btn-primary btn-block waves-effect" type="submit">Publicar</button>
            </div>
          </form>
        </div>

        <div v-else>
          <h6 class="text-center">Debe haber inciado sesion para hacer un comentario</h6>
        </div>
      </div>
      <!--.card-body-->
    </div>
    <!--.card-->
    <!--.col-lg-10.mx-auto-->
  </div>
  <!--.row-->
</template>

<script>
export default {
  props: ["id_entrada", "user_id"],
  data() {
    return {
      comentario: "",
      comentarios: [],
      hay_comentarios: false
    };
  },
  methods: {
    mostrar_formulario_respuesta(e) {
      var id = e.target.id;

      var id = id.split("-");

      if ($("#modal-reply-" + id[2]).css("height") == "0px") {
        $("#button-reply-" + id[2]).html("Ocultar");
        $("#modal-reply-" + id[2])
          .css({
            opacity: "1"
          })
          .removeClass("desaparecer");
      } else if ($("#modal-reply-" + id[2]).css("height") == "105.967px") {
        $("#button-reply-" + id[2]).html("Responder");

        $("#modal-reply-" + id[2])
          .css({
            opacity: "0"
          })
          .addClass("desaparecer");
      }
    },
    enviar_comentario() {
      const params = {
        entrada_id: this.id_entrada,
        comentario: this.comentario
      };

      axios
        .post("../api/comentario", params)
        .then(response => {
          this.$alertify.success("Su comentario sera comprobado");
        })
        .catch(error => {
          console.log(error);
        });
    },
    mostrar_comentarios() {
      let url = "../api/comentarios/" + this.id_entrada;
      axios
        .get(url)
        .then(response => {
          this.comentarios = response.data;
          if (this.comentarios.length > 0) {
            this.hay_comentarios = true;
          }

          this.comentarios.forEach(comentario => {
            comentario.created_at = comentario.created_at.replace("-", " ");
            comentario.created_at = comentario.created_at.replace("-", " ");
            var dia = comentario.created_at.split(" ")[0];
            var mes = comentario.created_at.split(" ")[1];
            var year = comentario.created_at.split(" ")[2];

            if (mes == "Dec") {
              mes = "Dic";
            }

            comentario.created_at = dia + " " + mes + " " + year;

            if (comentario.user.imagen_perfil != null) {
              comentario.user.imagen_perfil =
                "../storage/img/usuarios/" + comentario.user.imagen_perfil;
            } else {
              comentario.user.imagen_perfil =
                "../storage/img/usuarios/anonimus.jpg";
            }
          });
        })
        .catch(error => {
          console.log(error);
        });
    }
  },
  mounted() {
    this.mostrar_comentarios();
  }
};
</script>

<style scoped>
@media (min-width: 768px) {
  .img-avatar-comment {
    height: 65px;
    width: 100%;
  }
}

@media (max-width: 767px) {
  .img-avatar-comment {
    height: 100px;
    width: 100px !important;
  }
}

.card-comments img {
  width: 4rem;
}

.ocultar {
  opacity: 0;
}

.desaparecer {
  height: 0px !important;
}
.card-header {
  border: 1px solid rgba(0, 0, 0, 0.125);
}
</style>
