<template>
	<div class="container mx-auto mt-5">

    
    <div class="row">
      
      <!--panel-body-login-1-->
      <div id="panel-login1" class="panel panel-default col-lg-7 panel-login1 card ">
        <div class="panel-heading">
          <h3 class="panel-title"><b>Contacto</b></h3>
        </div>

        <div class="panel-body card-body">
          <p>Ponte en contacto por aquí</p>
          
          <form action="modules/contacto/enviar-correo.php" onsubmit="return validacion()" method="post">    
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-user"></i></span>
              <input type="text" id="input-nombre" class="form-control" name="nombre" placeholder="Nombre" aria-describedby="basic-addon1">
            </div>
            <br>
            
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-chevron-right"></i></span>
              <input type="text" id="input-apellido" class="form-control" name="apellido" placeholder="Apellido" aria-describedby="basic-addon1">
            </div>
            <br>
            
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-envelope"></i></span>
              <input type="text" id="input-correo" class="form-control" name="email" placeholder="Correo" aria-describedby="basic-addon1">
            </div>
            <br>
            
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-phone"></i></span>
              <input type="text" id="input-telefono" class="form-control" name="telefono" placeholder="Telefono" aria-describedby="basic-addon1">
            </div>
            <br>
            
            <div class="input-group">
              <span class="input-group-addon" id="basic-addon1"><i class="glyphicon glyphicon-edit"></i></span>
              <textarea id="input-mensaje" class="form-control" name="mensaje" placeholder="Mensaje" aria-describedby="basic-addon1" style="margin: 0px; height: 85px;"></textarea>
            </div>
            <br>
            
            <button class="btn btn-primary" id="btn" type="submit">Enviar</button>
          </form>
          <br>
          <div id="message-form-validation"></div>
          
        </div>
      </div>

      <div class="col-lg-1 col-0">
        
      </div>
      <!--.panel-login-1-->
      <!--panel-login-2-->
      <div id="panel-login2" class="panel panel-default panel-login2 col-lg-4 card">
        <div class="panel-body">
          <h4>Quienes somos</h4>
           <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam ornare, leo nec sodales convallis, odio nibh venenatis nisl, at tempor erat nulla ac urna. Donec varius sit amet augue at laoreet. Ut venenatis justo nec quam sodales, ac fringilla dui fermentum. Pellentesque eu rhoncus dui, dignissim efficitur augue. Quisque vel tellus eu nisl vehicula iaculis et ac justo. Phasellus vestibulum felis dignissim ligula faucibus venenatis. Integer gravida neque aliquet lacus sollicitudin commodo.</p>
          <h4>Contacto</h4>
           <p>¿Tienes dudas sobre DevInter?. Contáctanos y dinos tus preguntas o problemas de la plataforma y en 24 a 48 horas seras respondido por un experto de DevInter por correo.</p>
          
          <!--<h4>Siguenos</h4>
          <a href="#facebook"><i class="socicon socicon-facebook"></i></a>
          <a href="#twitter"><i class="socicon socicon-twitter"></i></a>
          <a href="#google "><i class="socicon socicon-googleplus"></i></a>
          <br>-->
          
          <div id="footer-copyright">
            <span class="logoL1">Dev</span><span class="logoL2">Inter</span> <b>Copyright 2016</b>
          </div>
          
        </div>
      </div>
      <!--.panel-login-2-->
    </div>



	</div>
</template>

<script>
	
</script>

<style scoped>
.logoL1, .logoL2 {font-weight:bold;} .ll1{font-size:170%;}
.logoL1 {color:#858688;}
.logoL2 {color:#00b6ff;}

/*body {background:url(https://data.bancodedatos.cf/img/group?cdn=2521&select=3);background-position:fixed;}*/
*{
  margin:0; 
}
body{
  
  background-color: #eee;
}
.panel-title{
  font-size: 2em;
}
.panel-login1 {
  margin-top:0.5%;
}

.panel-login2 {
  margin-top: 5%;
  border-radius: 5px;
  padding: 2%;
  border:2px solid black; 
}

.footer-copyright {
  text-align:right;
}

.socicon {
  font-size:230%;
}
.socicon:hover {
  font-size:250%;
  -webkit-transition:all 0.3s;
  -moz-transition:all 0.3s;
  transition:all 0.3s;
  text-decoration:none;  
}
.form-control{
  width: 75%;
  padding: 12px 20px;
  margin: 8px 0;
  box-sizing: border-box;
  border: 3px solid #ccc;
  -webkit-transition: 0.5s;
  transition: 0.5s;
  outline: none;
  border-radius: 5px;
  resize: none;
  font-size: 1em;

}
.form-control:focus{
  border: 3px solid #555;
}


@media screen and (max-width: 700px) 
{
  .form-control 
  {    
    width: 100%;
  }
}




.panel-body{
  color: black;
  font-size: 1em;
}




.panel-body h4{
  margin: 5% 0;
}
.panel-body a{
  margin: 0 2%;
}
#btn{
  width: 75%;
  background-color: #ccc;
  border: none;
  color: white;
  padding: 16px 32px;
  text-decoration: none;
  margin: 4px 2px;
  cursor: pointer;
  -webkit-transition:all 0.5s;
  -moz-transition: all 0.5;
  font-size: 1.1em;
}


@media screen and (max-width: 700px) 
{
  #btn 
  {
    width: 100%;
  }
}



#btn:hover{
  background-color: black;
}
.footer{
  top: 90%;
}
</style>