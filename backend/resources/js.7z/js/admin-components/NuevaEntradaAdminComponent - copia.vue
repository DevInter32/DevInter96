<template>


    <div >
        <br>

        <div class="row col-6 mb-3">
            

            <div class="card ">

                <div class="card-body row">
                    <div class="col-8">
                        <h3>Nueva Entrada</h3>
                    </div>

                </div>


            </div>
        </div>
        
            <div class="card pb-4">
            
                <form @submit.prevent="publicar_entrada" enctype="multipart/form-data">
                    
               
                    <h4 class="text-center"><strong>Titulo de la entrada</strong></h4>
                    <div class="col-8 mx-auto">
                        <input type="text" class="form-control" v-model="titulo">
                    </div>
                
                    <h5 class="text-center mt-4">Descripcion de la entrada</h5>
                <div class="row">
                    <div class="col-10 mx-auto">
                        <ckeditor :editor="editor" v-model="editorData" :config="editorConfig"></ckeditor>  
                    </div>

                 </div>

                 <div class="row mt-4">
                     <div class="col-3 text-center">Subir Imagen previa</div>

                     <div class="col-6">
                         <input type="file" class="form-control" id="file_img_previa">
                     </div>
                 </div>

                 <div class="row">
                     <div class="col-3 text-center">Subir Imagen Completa</div>

                     <div class="col-6">
                         <input type="file" class="form-control" id="file_img_completa">
                     </div> 
                 </div>

                 <div class="row mt-3">
                     <div class="col-6 mx-auto">
                         <button class="btn btn-success btn-block">Publicar entrada</button>
                     </div>
                 </div>
            
             </form>


            </div>



            



    </div>
</template>

<script>
    import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
    import SimpleUploadAdapter from '@ckeditor/ckeditor5-upload/src/adapters/simpleuploadadapter';

/*ClassicEditor
    .create( document.querySelector( '#editor' ), {
        plugins: [ SimpleUploadAdapter, ... ],
        toolbar: [ ... ],
        simpleUpload: {
            // The URL that the images are uploaded to.
            uploadUrl: 'http://example.com',

            // Headers sent along with the XMLHttpRequest to the upload server.
            headers: {
                'X-CSRF-TOKEN': 'CSFR-Token',
                Authorization: 'Bearer <JSON Web Token>'
            }
        }
    } )
    .then( ... )
    .catch( ... );*/


   /* class MyUploadAdapter {
        constructor( loader ) {
            // The file loader instance to use during the upload.
            this.loader = loader;
        }

        // Starts the upload process.
        upload() {
            // Update the loader's progress.
            server.onUploadProgress( data => {
                loader.uploadTotal = data.total;
                loader.uploaded = data.uploaded;
            } );

            // Return a promise that will be resolved when the file is uploaded.
            return loader.file
                .then( file => server.upload( file ) );
        }

        // Aborts the upload process.
        abort() {
            // Reject the promise returned from the upload() method.
            server.abortUpload();
        }
    }*/





    export default {
        name: 'app',
        data() {
            return {
                titulo:'',
                editor: ClassicEditor,
                upload:SimpleUploadAdapter,
                editorData: '<p>Content of the editor.</p>',
                editorConfig: {
                  
                }
            };
        },
        methods:{
            publicar_entrada(){
                var formData = new FormData();

                var img_previa = document.querySelector("#file_img_previa");
                console.log(img_previa);
                formData.append("file",img_previa.files[0]);

                var img_completa = document.querySelector("#file_img_completa");

                formData.append("file_completa",img_previa.files[0]);

                formData.append("titulo",this.titulo);

                formData.append("descripcion",this.editorData);

                axios.post("../api/entradas",formData)
                .then((response)=>{
                    this.$alertify.success('Se ha publicado su entrada');
                })
                .catch((error)=>{
                    console.log(error)
                })


            }
   
        },
        /*created(){
            this.editor
                .create( document.querySelector( '#editor' ), {
                    plugins: [ this.upload],
                    simpleUpload: {
                        // Feature configuration.
                    }
                } )
                .then((response)=>{
                    console.log(response)
                })
                .catch((error)=>{
                    console.log(error)
                })
                }*/
    }
</script>

<style >



</style>