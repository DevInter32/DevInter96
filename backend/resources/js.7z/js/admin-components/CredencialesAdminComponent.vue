<template>



<div class="container py-5 " >
	<div class="w-75 mt-5 mx-auto">
		<div class="card">
			<div class="card-body " id="registro-curso" >
				<form method="post" @submit.prevent="realizar_cambios">
					<h4 class="text-center">Cambio de credenciales</h4>
					<hr class="w-75 mx-auto">

					<div class="row">


						<div class="col-4 mt-4">
							<strong>Nombre de usuario:</strong>
						</div>
						<div class="col-8 mt-4">
							<input type="text" name="nombre_usuario" class="form-control" v-model="usuario">
						</div>


						<div class="col-4 mt-4">
							<strong>Contraseña:</strong>
						</div>
						<div class="col-8 mt-4">
							<input type="password" name="contrasena" class="form-control" v-model="clave">
						</div>


						<div class="col-4 mt-4">
							<strong>Nueva Contraseña:</strong>
						</div>
						<div class="col-8 mt-4">
							<input type="password" name="contrasena" class="form-control" v-model="nueva_clave">
						</div>


						<div class="col-6 mx-auto">
							<button type="submit" class="btn btn-primary btn-block mt-5" name="iniciar_sesion" value="true">Realizar Cambios</button>
						</div>


					</div>
				</form>
			</div>
		</div>
	</div>
</div>









</template>


<script>
	export default{
		data(){
			return{
				usuario:'',
				clave:'',
				nueva_clave:''
			}
		},
		methods:{
			realizar_cambios(){
				const params={
					usuario:this.usuario,
					clave:this.clave,
					nueva_clave:this.nueva_clave
				}
				axios.put('../api/usuarios',params)
				.then((response)=>{
                    this.$alertify.success('Se ha realizado el cambio');
				})
				.catch((error)=>{
					console.log(error)
				})
			}
		}
	}
</script>

<style>
	
</style>