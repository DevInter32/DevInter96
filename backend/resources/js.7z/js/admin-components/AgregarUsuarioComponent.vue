<template>
  <div>
    <br />

    <div class="row col-md-8 col-lg-6 col-12">
      <div class="card">
        <div class="card-body row">
          <div class="col-md-4 col-12">
            <h3 class="text-center">Agregar Usuario</h3>
          </div>
          <div class="col-md-8 col-8 mx-auto">
            <router-link
              to="/admin/usuarios"
              class="btn btn-primary btn-block"
            >Ver todos los usarios</router-link>
          </div>
        </div>
      </div>
    </div>

    <br />
    <br />

    <div class="w-75 mx-auto mb-5">
      <div class="card">
        <div class="card-body" id="registro-curso">
          <form method="post" @submit.prevent="agregar_usuario">
            <h4 class="text-center">Formulario de Usuario</h4>
            <hr class="w-75 mx-auto" />
            <validation-errors :errors="validationErrors" v-if="validationErrors"></validation-errors>
            <div class="row">
              <div class="col-4 mt-4">
                <strong>Nombre de usuario:</strong>
              </div>
              <div class="col-8 mt-4">
                <input type="text" name="nombre_usuario" class="form-control" v-model="usuario" />
              </div>

              <div class="col-4 mt-4">
                <strong>Correo</strong>
              </div>
              <div class="col-8 mt-4">
                <input type="text" name="nombre_usuario" class="form-control" v-model="correo" />
              </div>

              <div class="col-4 mt-4">
                <strong>Contraseña:</strong>
              </div>
              <div class="col-8 mt-4">
                <input type="password" name="contrasena" class="form-control" v-model="clave" />
              </div>

              <div class="col-4 mt-4">
                <strong>Repetir Contraseña</strong>
              </div>
              <div class="col-8 mt-4">
                <input
                  type="password"
                  name="repetir_contrasena"
                  class="form-control"
                  v-model="clave_confirmacion"
                />
              </div>

              <div class="col-4 mt-4">
                <strong>Rol</strong>
              </div>
              <div class="col-8 mt-4">
                <select name id class="form-control" v-model="rol_usuario">
                  <option value="0" disbaled>Seleccione</option>

                  <option v-for="(rol) in roles" :value="rol.id" :key="rol.id">{{rol.name}}</option>
                </select>
              </div>

              <div class="col-6 mx-auto">
                <button
                  type="submit"
                  class="btn btn-primary btn-block mt-5"
                  name="iniciar_sesion"
                  value="true"
                >Realizar Cambios</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      roles: [],
      rol_usuario: "",
      usuario: "",
      correo: "",
      clave: "",
      clave_confirmacion: "",
      validationErrors: ""
    };
  },
  methods: {
    agregar_usuario() {
      const params = {
        name: this.usuario,
        password: this.clave,
        password_confirmation: this.clave_confirmacion,
        email: this.correo,
        rol: this.rol_usuario
      };
      axios
        .post("../api/usuarios", params)
        .then(response => {
          console.log(response);
          //this.$alertify.success('Se ha realizado el cambio');
        })
        .catch(error => {
          console.log(error);
          this.validationErrors = error.response.data.errors;
        });
    },
    cargar_roles() {
      axios.get("../api/roles").then(response => {
        this.roles = response.data;
      });
    }
  },
  created() {
    this.cargar_roles();
  }
};
</script>
