<template>
	<div>
		<br>

        <div class="row col-md-8 col-lg-6 col-12">
            

            <div class="card ">

                <div class="card-body row">
                    <div class="col-md-6 col-12">
                        <h3 class="text-center">Comentarios</h3>
                    </div>

                </div>


            </div>
        </div>


		<br><br>
        <div class="alert alert-primary text-center" v-if="processing"><span>Procesando Informacion... </span></div>
        <v-server-table ref="table" :columns="columns" :url="url" :options="options">


            <div slot="acciones" slot-scope="props">
                <button class="btn btn-info" @click="actualizar_estado(props.row)">Cambiar estado</button>
     
            </div>
        </v-server-table>

	</div>
</template>


<script>
	export default{
		data () {
        	const labels={
        		usuario:"Autor del comentario",
        		entrada:"Entrada del comentario",
        		comentario:"Descripcion del comentario",
        		fecha:"Fecha de publicacion",
                estado:"Estado del comentario",
        		accion:"Acciones"
        	}

            return {
                processing:false,
                url: '../api/comentarios',
                columns: ['id','user', 'entrada', 'comentario','created_at','estado','acciones'],
                options: {
                    filterByColumn: true,
                    perPage: 10,
                    perPageValues: [10, 25, 50, 100, 500],
                    headings: {
                        user:labels.usuario,
                        entrada:labels.entrada,
                        comentario:labels.comentario,
                        estado:labels.estado,
                        created_at:labels.fecha,
                        accion:labels.accion


                    },
                    customFilters: ['entrada'],
                    sortable: ['entrada'],
                    filterable: ['entrada'],
                    requestFunction: function (data) {
                        var datos = axios.get(this.url, {
                            params: data
                        })
                        .then((response)=>{
                            response.data.data.forEach((datos)=>{
                                datos.entrada = datos.entrada.titulo
                                datos.user = datos.user.name

                            })
                            console.log(response)
                            return response;
                        })
                        .catch(function (e) {
                            this.dispatch('error', e);
                        }.bind(this));

                        return datos;
                    }


                }
            }
        },
        methods:{
            actualizar_estado(fila){    
                this.processing =true;
                setTimeout(()=>{
                    const params = {id:fila.id}
                    axios.put('../api/comentario/update',params)
                    .then((response)=>{
                        this.$refs.table.refresh();
                        this.processing=false;
                    })
                    .catch((error)=>{
                        console.log(error);
                        this.processing=false;
                    })
                    
                },1500)
            }
        }
	}
</script>