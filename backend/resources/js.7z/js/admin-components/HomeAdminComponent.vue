<template>
	<div class="p-3">
		<h3>Bienvenidos a la sección de admin</h3>
	</div>
</template>