import Vue from 'vue'
import Router from 'vue-router'

//const lazyLoad = (view) => () =>
//    import (`@/vistas/${view}.vue`)

function lazyLoad(view) {
    return () => (`@/vistas/${view}.vue`)
}

const renderView = (path, componente, nombre, titulo, props = false, auth = false) => {
    return {
        path: `${path}`,
        component: lazyLoad(`${componente}`),
        name: nombre,
        props: props,
        meta: {
            requiresAuth: auth,
            title: titulo
        }
    }
}

Vue.use(Router)

const router = new Router({
    linkActiveClass: 'active',
    scrollBehavior: () => ({ y: 0 }),
    mode: 'hash',
    routes: [
        renderView('/', 'Inicio/Inicio', 'inicio', 'Inicio'),
        renderView('/contacto', 'Contacto/Contacto', 'contacto', 'Contacto'),
        renderView('/login', 'Login/Login', 'login', 'Iniciar sesión'),
        renderView('/register', 'Registrarse/Registrarse', 'registrarse', 'Registrarse'),
        renderView('/blog', 'Blog/Blog', 'blog', 'Blog'),
    ]
})




export default router;