import { API_ENDPOINT } from '@/constantes/constantes';

const store = {
    state: {},
    getters: {},
    mutations: {

    },
    actions: {

        iniciarSesion({}, usuario) {

            return new Promise((resolve, reject) => {

                var formData = new FormData();
                formData.append('email', usuario.email);
                formData.append('password', usuario.password);

                fetch(`${API_ENDPOINT}login`, {
                        method: 'POST',
                        body: formData
                    }).then(response => response.json())
                    .catch(error => reject(error))
                    .then(response => resolve(response));

            })
        },

    }
}

export default store