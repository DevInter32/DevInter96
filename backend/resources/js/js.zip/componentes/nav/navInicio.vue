<template>
    <header>
         <router-link to="/" ><h1>Dev<b>Inter</b></h1></router-link>

         <input type='checkbox' id='menu-bar'>

         <label class='icon-menu' for='menu-bar'></label>

         <nav class='menu_dev'> 

             <router-link to="/blog" class='item medio'>Blog</router-link>

             <router-link to="/contacto" class='item medio' >Contacto</router-link>
             <router-link to="/login" class='item medio' >Iniciar Sesión</router-link>
             <router-link to="/register" class="item medio">Registrarse</router-link>
         </nav>
    </header>
</template>

<script>
export default {
    name:'navInicio',        
}
</script>

<style lang="scss" scoped>

</style>