<template>
  <div>
    <section class="banner banner--principal">
      <div class="banner__media">
        <img src="../../assets/img/developer-001.jpg" alt="Titulo" />
      </div>
      <!-- /.banner__media -->
      <div class="banner__content content">
        <h2 class="banner__title">
          ¡Desea aprender a crear su propia web! ¡pero! ¿no sabes como?
        </h2>
        <!-- /.banner__title -->
        <p>
          Da tus primeros pasos en el mundo de la web con nuestros cursos.
        </p>
      </div>
      <!-- /.banner__content -->
    </section>
    <!-- /.banner -->

    <section class="contenedor">
      <!--section class="container"-->
      <div class="wrap">
        <div class="block">
          <div class="item__block">
            <div class="item__status status--soon">Pronto</div>
            <!-- /.item__status -->
            <h2 class="item__title">
              <a href="?action=single-curso" title="Titulo">
                Aprende a maquetear tus propios diseños web
              </a>
            </h2>
            <!-- /.item__title -->
            <div class="content">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At
                quae molestias iusto! Blanditiis quidem incidunt facilis
                praesentium labore, maiores a.
              </p>
            </div>
            <!-- /.content -->
            <div class="item__level level--start">
              <span></span>
              Basico
            </div>
            <!-- /.item__level -->
          </div>
          <!-- /.item__block -->
          <div class="item__block">
            <div class="item__status status--soon">Pronto</div>
            <!-- /.item__status -->
            <h2 class="item__title">
              <a href="?action=single-curso" title="Titulo">
                Crea tus eventos y controla tu Web con este leguaje, aprende JS,
                JQuery, Angular, AJAX y Node JS.
              </a>
            </h2>
            <!-- /.item__title -->
            <div class="content">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At
                quae molestias iusto! Blanditiis quidem incidunt facilis
                praesentium labore, maiores a.
              </p>
            </div>
            <!-- /.content -->
            <div class="item__level level--mid">
              <span></span>
              <span></span>
              Intermedio
            </div>
            <!-- /.item__level -->
          </div>
          <!-- /.item__block -->
          <div class="item__block">
            <div class="item__status status--soon">Pronto</div>
            <!-- /.item__status -->
            <h2 class="item__title">
              <a href="?action=single-curso" title="Titulo">
                Dale inteligencia artificial a tu Web con PHP y destaca tu
                sitios de todos los demas.
              </a>
            </h2>
            <!-- /.item__title -->
            <div class="content">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At
                quae molestias iusto! Blanditiis quidem incidunt facilis
                praesentium labore, maiores a.
              </p>
            </div>
            <!-- /.content -->
            <div class="item__level level--hard">
              <span></span>
              <span></span>
              <span></span>
              Avanzado
            </div>
            <!-- /.item__level -->
          </div>
          <!-- /.item__block -->
          <div class="item__block">
            <div class="item__status status--soon">Pronto</div>
            <!-- /.item__status -->
            <h2 class="item__title">
              <a href="?action=single-curso" title="Titulo">
                Crea tu base de datos con este poderoso lenguanje de
                programacion.
              </a>
            </h2>
            <!-- /.item__title -->
            <div class="content">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At
                quae molestias iusto! Blanditiis quidem incidunt facilis
                praesentium labore, maiores a.
              </p>
            </div>
            <!-- /.content -->
            <div class="item__level level--start">
              <span></span>
              Basico
            </div>
            <!-- /.item__level -->
          </div>
          <!-- /.item__block -->
          <div class="item__block">
            <div class="item__status status--soon">Pronto</div>
            <!-- /.item__status -->
            <h2 class="item__title">
              <a href="?action=single-curso" title="Titulo">
                Aprede a crear tus propias aplicaciones personalizadas con Swift
                o Xcode.
              </a>
            </h2>
            <!-- /.item__title -->
            <div class="content">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At
                quae molestias iusto! Blanditiis quidem incidunt facilis
                praesentium labore, maiores a.
              </p>
            </div>
            <!-- /.content -->
            <div class="item__level level--mid">
              <span></span>
              <span></span>
              Intermedio
            </div>
            <!-- /.item__level -->
          </div>
          <!-- /.item__block -->
          <div class="item__block">
            <div class="item__status status--soon">Pronto</div>
            <!-- /.item__status -->
            <h2 class="item__title">
              <a href="?action=single-curso" title="Titulo">
                Python
              </a>
            </h2>
            <!-- /.item__title -->
            <div class="content">
              <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. At
                quae molestias iusto! Blanditiis quidem incidunt facilis
                praesentium labore, maiores a.
              </p>
            </div>
            <!-- /.content -->
            <div class="item__level level--hard">
              <span></span>
              <span></span>
              <span></span>
              Avanzado
            </div>
            <!-- /.item__level -->
          </div>
          <!-- /.item__block -->
        </div>
        <!-- /.block -->
      </div>
      <!-- /.wrap -->
    </section>
    <!-- /.container -->
  </div>
</template>

<script>
export default {
    name:'Inicio',
};
</script>

<style></style>
